//
//  TableViewController.h

#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewController

@property NSArray *entries;
- (IBAction)logout:(id)sender;

@end
