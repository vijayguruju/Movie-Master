//
//  Details.h
//  Register Login Movies
//
//  Created by CodeFrux on 2/11/17.
//  Copyright © 2017 Sajwalit. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Details : NSObject


@property(nonatomic,strong)NSString *username;
@property(nonatomic,strong)NSString *password;
@property(nonatomic,strong)NSString *confirmpassword;

@end
