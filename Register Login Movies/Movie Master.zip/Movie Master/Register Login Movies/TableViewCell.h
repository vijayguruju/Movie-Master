//
//  TableViewCell.h

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell

@end
