//
//  Details.m
//  Register Login Movies
//
//  Created by CodeFrux on 2/11/17.
//  Copyright © 2017 Sajwalit. All rights reserved.
//

#import "Details.h"

@implementation Details

@end
